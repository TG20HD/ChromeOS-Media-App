import {loadTimeData} from '//resources/js/load_time_data.js';
import '//resources/ash/common/load_time_data.m.js';
loadTimeData.data = {"appTitle":"Gallery","fileFilterAudio":"Audio Files","fileFilterImage":"Image Files","fileFilterVideo":"Video Files","fontfamily":"Roboto, sans-serif","fontsize":"75%","language":"en","textdirection":"ltr"};